<?php

namespace Ens\GoodJobBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EnsGoodJobBundle extends Bundle
{
}
