<?php

/* EnsGoodJobBundle::layout.html.twig */
class __TwigTemplate_139bf145248eb3e1dfd0895885fe16ffb96c5cc0a51a3f8af49dbec59c7bc5e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "    <!DOCTYPE html>
    <html>
        <head>
            <title>
                ";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        // line 8
        echo "            </title>
            <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
            <link rel=\"shortcut icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/ensgoodjob/images/favicon.ico"), "html", null, true);
        echo "\" />
            ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "            ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 23
        echo "        </head>
        <body>
            <div id=\"container\">
                <div class=\"top-header\">
                    <ul id=\"menu_horizontal\">
                        <li class=\"li-menuHeader\">
                            <a href=\"";
        // line 29
        echo $this->env->getExtension('routing')->getPath("EnsGoodJobBundle_homepage");
        echo "\">
                                <img src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/ensgoodjob/images/logo.jpg"), "html", null, true);
        echo "\" alt=\"Good Job - Le partenaire des geeks\" class=\"imgLogo\" />
                            </a>
                        </li>
                        <li class=\"li-menuHeader\">
                            <a href=\"";
        // line 34
        echo $this->env->getExtension('routing')->getPath("ens_job_new");
        echo "\" class=\"menu-header\">
                                
                                    Déposer une offre
                              
                            </a>
                        </li>
                        <li class=\"li-menuHeader\">
                            <a href=\"";
        // line 41
        echo $this->env->getExtension('routing')->getPath("EnsGoodJobBundle_homepage");
        echo "\" class=\"menu-header\">
                                
                                     Rechercher une offre
                              
                            </a>
                        </li>
                        <li class=\"li-menuHeader\">
                            <a href=\"";
        // line 48
        echo $this->env->getExtension('routing')->getPath("EnsGoodJobBundle_homepage");
        echo "\" class=\"menu-header\">
                                
                                    Créer sont CV
                              
                            </a>
                        </li>
                        <li class=\"li-menuHeader\">
                            <a href=\"";
        // line 55
        echo $this->env->getExtension('routing')->getPath("EnsGoodJobBundle_homepage");
        echo "\" class=\"menu-header\">
                                
                                     Rechercher un Candidat
                               
                            </a>
                        </li>
                    </ul>
                </div>



                <div id=\"header\">
                    <div class=\"content\">

                        <div class=\"contentSlide\">
                            <div id='coin-slider'>
                                <a href=\"";
        // line 71
        echo $this->env->getExtension('routing')->getPath("EnsGoodJobBundle_homepage");
        echo "\" target=\"_blank\">
                                    <img src='";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/ensgoodjob/images/job.jpg"), "html", null, true);
        echo "' >
                                    <span>
                                        Description for img01
                                    </span>
                                </a>
                                <a href=\"";
        // line 77
        echo $this->env->getExtension('routing')->getPath("EnsGoodJobBundle_homepage");
        echo "\">
                                    <img src='";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/ensgoodjob/images/job2.jpg"), "html", null, true);
        echo "' >
                                    <span>
                                        Description for imgN
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div id=\"sub_header\">

                            <div class=\"search\">
                                <form action=\"\" method=\"get\">
                                    <input type=\"text\" name=\"keywords\" id=\"search_keywords\" id=\"srchval\" onclick=\"clearf()\" value=\" Ecrivez quelques mots clés (ville, pays, poste, ...)\"/>
                                    <input type=\"submit\" value=\"rechercher\" classe=\"submitR\" />
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


                <div id=\"content\">
                    ";
        // line 99
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 100
            echo "                        <div class=\"flash_notice\">
                            ";
            // line 101
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 104
        echo "                    

                    ";
        // line 106
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 107
            echo "                        <div class=\"flash_error\">
                            ";
            // line 108
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 111
        echo "
                    <div class=\"content\">
                        ";
        // line 113
        $this->displayBlock('content', $context, $blocks);
        // line 115
        echo "                    </div>
                    <script type=\"text/javascript\">
                        \$(document).ready(function() {
                            \$('#coin-slider').coinslider({ width:783, navigation: false, delay: 5000 });
                        });
                    </script>
                </div>


                <div id=\"footer\">
                    <div class=\"content\">

                        <ul>
                            <li><a href=\"\">Mention legales </a></li>
                            <li class=\"\"><a href=\"\">Mention legales</a></li>
                            <li><a href=\"\">Mention legales</a></li>
                            <li class=\"\"><a href=\"\">Mention legales</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </body>
    </html>";
    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        // line 6
        echo "                    Good Job - Le partenaire des geeks
                ";
    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 12
        echo "                <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/ensgoodjob/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
            ";
    }

    // line 14
    public function block_javascripts($context, array $blocks = array())
    {
        // line 15
        echo "                <script langage=\"text/javascript\">
                    function clearf(){
                        document.getElementById('srchval').value=\"\";
                    }
                </script>
                <script type=\"text/javascript\" src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/ensgoodjob/js/jquery-1.4.2.js"), "html", null, true);
        echo "\"></script>
                <script type=\"text/javascript\" src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/ensgoodjob/js/coin-slider.min.js"), "html", null, true);
        echo "\"></script>
            ";
    }

    // line 113
    public function block_content($context, array $blocks = array())
    {
        // line 114
        echo "                        ";
    }

    public function getTemplateName()
    {
        return "EnsGoodJobBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  262 => 114,  259 => 113,  253 => 21,  249 => 20,  242 => 15,  239 => 14,  232 => 12,  229 => 11,  224 => 6,  221 => 5,  194 => 115,  192 => 113,  188 => 111,  179 => 108,  176 => 107,  172 => 106,  168 => 104,  159 => 101,  156 => 100,  152 => 99,  128 => 78,  124 => 77,  116 => 72,  112 => 71,  93 => 55,  83 => 48,  73 => 41,  63 => 34,  56 => 30,  52 => 29,  44 => 23,  41 => 14,  39 => 11,  35 => 10,  31 => 8,  29 => 5,  23 => 1,);
    }
}
